
# Assets para Mi Barista Imusa

Este archivo contiene todos los assets generados automáticamente.

## Estructura
```
assets/
├── icons/
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-144.png
│   ├── icon-152.png
│   ├── icon-192.png
│   ├── icon-384.png
│   └── icon-512.png
└── img/
    ├── coffee-bg.jpg
    └── og-image.jpg
```

Todos los archivos fueron generados usando Canvas en el navegador.
                